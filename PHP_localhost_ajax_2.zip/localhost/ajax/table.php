
<script
    src="https://code.jquery.com/jquery-3.6.0.min.js"
    integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4="
    crossorigin="anonymous">

</script>


<script>
$(document).ready(function(){
    select();
});



//-------- Select data ------------
function select(){
    $.ajax({
        method: "POST",
        url: "table_ajax.php",
        data: {action: 'select' },
        async:false,
    })
    .done(function( html ) {
        $( "#table" ).html( html );
    });
}

//-------- Edit Name ------------
function edit(id){

    var name = $('#name_' + id).val();
    console.log('id =' + id);
    console.log('name =' + name);

    $.ajax({
        method: "POST",
        url: "table_ajax.php",
        data: {action: 'edit', name : name, id : id},
        async:false,
    })
    .done(function( html ) {
        //$( "#table" ).html( html );
        console.log('Edit Status = ' + html);
        select();
    });
    
}

//-------- Delete Row ------------
function delete_row(id){

    console.log('id =' + id);

    $.ajax({
        method: "POST",
        url: "table_ajax.php",
        data: {action: 'delete', id : id},
        async:false,
    })
    .done(function( html ) {
        //$( "#table" ).html( html );
        console.log('Delete Status = ' + html);
        select();
    });

}


//-------- add Row ------------
function add_row(){
    var new_name = $('#new_name').val();
    $.ajax({
        method: "POST",
        url: "table_ajax.php",
        data: {action: 'add', new_name : new_name},
        async:false,
    })
    .done(function( html ) {
        //$( "#table" ).html( html );
        console.log('Add Status = ' + html);
        select();
    });
}

</script>

<div id='table'>
 


</div>
<br>
Add new name : 
<input type="text" id='new_name'>
<input type="button" value="Add name" onclick="add_row();">



