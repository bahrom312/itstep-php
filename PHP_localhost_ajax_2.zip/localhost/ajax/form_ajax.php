
<script
    src="https://code.jquery.com/jquery-3.6.0.min.js"
    integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4="
    crossorigin="anonymous">

</script>


<script>

function ajax(){
    var param_1 = $('#param_1').val();
    var param_2 = $('#param_2').val();

    //alert(param_1);
    var result_ajax = 0;

    $.ajax({
        method: "GET",
        url: "ajax.php",
        data: { param1: param_1, param2: param_2 },
        async:false,
    })
    .done(function( msg ) {
        //alert( "Result: " + msg );
        //result_ajax = msg;
        $( "#result_div" ).html( msg );
    });

    //var result_ajax=0;
    //alert( "Result: " + result_ajax );

    //$('#result_div').html(result_ajax);
}

</script>
param_1
<input type="text" name='param_1' id='param_1' value="0">
param_1
<input type="text" name='param_2' id='param_2' value="0">

<br>
<input type="button" value="Send Ajax " onclick="ajax()">

<br>
Result = 
<div id='result_div'> 
    0
</div>


