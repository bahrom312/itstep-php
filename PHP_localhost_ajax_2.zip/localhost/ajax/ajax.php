<?php


$param1 = $_GET['param1'] ?? 0;
$param2 = $_GET['param2'] ?? 0;

$summa = $param1 + $param2;

echo $summa;
