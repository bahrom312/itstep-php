<?php

//$conn = new mysqli('localhost', 'mysql', '');
//echo $conn->connect_error;

$conn = new PDO("mysql:host=localhost;dbname=academy", 'mysql', '');
$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

$action = $_POST['action'];
$name = $_POST['name'];
$id = $_POST['id'];
$new_name = $_POST['new_name'];



// Поиск по $name s
if ($action=='select'){
    $sql = "SELECT * FROM students";   
    $result = $conn->query($sql);

    echo "<table border ='1'>  ";

    while($row = $result->fetch(PDO::FETCH_ASSOC)){
    ?>
        <tr id = '<?php echo $row['id'];?>' > 
            <td> <?php echo $row['id'];?> </td>
            <td> <?php echo $row['name'];?> </td>
            <td>    
                <input type="text" id='name_<?php echo $row['id'];?>' style="width: 150;" >
                <input type="button" value="Edit" onclick="edit(<?php echo $row['id'];?>);">
            </td>
            <td>    
                <input type="button" value="Delete" onclick="delete_row(<?php echo $row['id'];?>);">
            </td>
        </tr>
    <?php
    }
    echo '</table>';
} //  if ($action=='select')


if ($action == 'edit'){
    $sql = "UPDATE students SET name='$name' WHERE id='$id'";   
    $result = $conn->query($sql);

    echo 'Edit OK';
}

if ($action == 'delete'){
    $sql = "DELETE FROM students WHERE id='$id'";   
    $result = $conn->query($sql);

    echo 'Delete OK';
}

if ($action == 'add'){

    $sql = "INSERT INTO students (name) 
            VALUES ('$new_name')";
    $result = $conn->query($sql);

    echo 'Add OK';
}
