<?php 
    $name = $_POST['name'] ?? '';
    $surname = $_POST['surname'] ?? '';
?>
<h3>Students form</h3>
<form action="form_insert.php" method="post">
    Name: <input type="text" name="name"/> 
    <br>
    Surname: <input type="text" name="surname"/> 
    <br>
    <input type="submit" name="submit"/> 
</form>

<?php 

$conn = new PDO("mysql:host=localhost;dbname=academy", 'mysql', '');
$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

if ($name){

    $sql = "INSERT INTO students (name, surname) 
    VALUES ('$name', '$surname')";

    $result = $conn->query($sql);
}




?>