<?php 



//$conn = new mysqli('localhost', 'mysql', '');
//echo $conn->connect_error;

$conn = new PDO("mysql:host=localhost;dbname=academy", 'mysql', '');
$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);


$action = $_POST['action'] ?? '';
$id = $_POST['id'] ?? '0';
$name = $_POST['name'] ?? '';

if ($action=='delete'){
    $sql = "DELETE FROM students WHERE id='$id'";   
    $result = $conn->query($sql);
}

if ($action=='edit'){
    $sql = "UPDATE students SET name='$name' WHERE id='$id'";   
    $result = $conn->query($sql);
}

if ($action=='upload'){
    $target_dir = "pics/";
    //$target_file = $target_dir.basename($_FILES["file_picture"]["name"], '.jpg');
    $target_file = $target_dir.'student_pic_'.$id.'.jpg';

    move_uploaded_file($_FILES["file_picture"]["tmp_name"], $target_file);
}

// Поиск по $name 
if ($action=='find'){
    $sql = "SELECT * FROM students WHERE name like '%$name%' "; 
    $result = $conn->query($sql);
}
else
{   // Показать все 
    $sql = "SELECT * FROM students";   
    $result = $conn->query($sql);
}


echo 'rowCount'.$result->rowCount()."\n";
echo '<table border=1> ';

while($row = $result->fetch(PDO::FETCH_ASSOC)){
    echo '<tr>';
    //var_dump($row);
        echo '<td> ';
        echo 'id = '.$row['id'];
        echo '</td>'."\n";;
        
        echo '<td>';
        echo 'Name = '.$row['name'];
        echo '</td>'."\n";

        echo '<td>';
        echo '<a href="database.php?action=delete&id='.$row['id'].'">DELETE</a>';
        echo '</td>'."\n";

        echo '<td>';
        ?>
            <form action="" method="POST" >
                <input type="hidden" name='id' value="<?php echo $row['id'] ?>">
                <input type="hidden" name='action' value="edit">
                <input type="text" name='name' style="width: 50;" >
                <input type="submit" value="Edit">
            </form>
        </td>

        <td>
        <form action="" method="POST" enctype="multipart/form-data">
            Выберите изображение:
            <input type="file" name="file_picture" 
                id="file_picture"  accept="image/jpeg"
            >
            <input type="hidden" name='id' value="<?php echo $row['id'] ?>">
            <input type="hidden" name='action' value="upload">
            <input type="submit" value="Загрузить" name="submit">
        </form>
        </td>
    <?php

    echo '</tr>'."\n";;
}
echo '</table>';
?>

<br>

<form action="" method="POST" >
    Name: 
    <input type="hidden" name='action' value="find">
    <input type="text" name='name' style="width: 100;" >
    <input type="submit" value="find">
</form>



